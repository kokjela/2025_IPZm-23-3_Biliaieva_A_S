import networkx as nx
import random

def route_cost(graph, route):
    return sum(nx.shortest_path_length(graph, route[i], route[i + 1], weight='travel_time')
               for i in range(len(route) - 1))

def mutate(route):
    i, j = random.sample(range(1, len(route) - 1), 2)
    route[i], route[j] = route[j], route[i]
    return route

def crossover(parent1, parent2):
    mid = len(parent1) // 2
    return parent1[:mid] + [node for node in parent2 if node not in parent1[:mid]]

def genetic_algorithm_optimize(graph, start, end, generations=50):
    points = [start, end]
    population = [random.sample(points, len(points)) for _ in range(10)]

    for _ in range(generations):
        population = sorted(population, key=lambda r: route_cost(graph, r))
        next_gen = population[:2]
        while len(next_gen) < len(population):
            p1, p2 = random.sample(population[:5], 2)
            child = mutate(crossover(p1, p2))
            next_gen.append(child)
        population = next_gen

    return population[0]