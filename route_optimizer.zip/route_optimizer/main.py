from genetic import genetic_algorithm_optimize
from map_plot import build_route_map
import osmnx as ox

place = "Kharkiv, Ukraine"
graph = ox.graph_from_place(place, network_type='walk')
graph = ox.add_edge_speeds(graph)
graph = ox.add_edge_travel_times(graph)

start = ox.distance.nearest_nodes(graph, 36.2304, 49.9935)
end = ox.distance.nearest_nodes(graph, 36.2484, 50.0040)

route = genetic_algorithm_optimize(graph, start, end)
build_route_map(graph, route, filename="route_map.html")