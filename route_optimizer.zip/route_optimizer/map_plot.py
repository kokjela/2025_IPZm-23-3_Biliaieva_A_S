import folium
import osmnx as ox
import networkx as nx

def build_route_map(graph, route, filename="route_map.html"):
    path = []
    for i in range(len(route) - 1):
        path += nx.shortest_path(graph, route[i], route[i+1], weight='travel_time')

    m = folium.Map(location=[50.0, 36.23], zoom_start=13)
    route_coords = [(graph.nodes[node]['y'], graph.nodes[node]['x']) for node in path]
    folium.PolyLine(route_coords, color="blue", weight=5).add_to(m)
    folium.Marker(route_coords[0], popup="Start", icon=folium.Icon(color='green')).add_to(m)
    folium.Marker(route_coords[-1], popup="End", icon=folium.Icon(color='red')).add_to(m)
    m.save(filename)
    print(f"Карта збережена у {filename}")