import osmnx as ox
import networkx as nx
import folium

print("Loading Kharkiv road graph...")
G = ox.graph_from_place("Kharkiv, Ukraine", network_type='walk')

start_coords = (49.9935, 36.2304)  # Start: Constitution Square
end_coords = (49.9860, 36.2547)    # End: Gorky Park

print("Finding nearest nodes...")
start_node = ox.distance.nearest_nodes(G, start_coords[1], start_coords[0])
end_node = ox.distance.nearest_nodes(G, end_coords[1], end_coords[0])

print("Calculating route using A*...")
route = nx.astar_path(G, start_node, end_node, weight='length')

print("Creating map...")
midpoint = ((start_coords[0] + end_coords[0]) / 2, (start_coords[1] + end_coords[1]) / 2)
route_map = folium.Map(location=midpoint, zoom_start=14)

route_coords = [(G.nodes[node]['y'], G.nodes[node]['x']) for node in route]
folium.PolyLine(route_coords, color="red", weight=5).add_to(route_map)

folium.Marker(location=start_coords, popup="Start", icon=folium.Icon(color='green')).add_to(route_map)
folium.Marker(location=end_coords, popup="End", icon=folium.Icon(color='red')).add_to(route_map)

output_file = "kharkiv_route_map.html"
route_map.save(output_file)

print(f"Map saved to {output_file}")


